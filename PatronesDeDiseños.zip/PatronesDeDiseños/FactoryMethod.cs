﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PatronesDeDiseños
{
    //Patron de diseño FactoryMethod
    public abstract class FactoryMethod
    {
        public abstract int CuantoBebiPorHora();
    }
}
